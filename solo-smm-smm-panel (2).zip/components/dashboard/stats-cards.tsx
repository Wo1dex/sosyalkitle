"use client"

import { TrendingUp, Package, Clock, CheckCircle } from "lucide-react"

const stats = [
  {
    icon: Package,
    label: "Toplam Sipariş",
    value: "1,234",
    change: "+12%",
    positive: true,
  },
  {
    icon: Clock,
    label: "Bekleyen",
    value: "23",
    change: "-5%",
    positive: true,
  },
  {
    icon: CheckCircle,
    label: "Tamamlanan",
    value: "1,198",
    change: "+18%",
    positive: true,
  },
  {
    icon: TrendingUp,
    label: "Bu Ay Harcama",
    value: "₺4,521",
    change: "+8%",
    positive: false,
  },
]

export function StatsCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <div key={index} className="glass rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <stat.icon className="w-5 h-5 text-primary" />
            </div>
            <span
              className={`text-xs font-medium px-2 py-1 rounded-full ${
                stat.positive ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"
              }`}
            >
              {stat.change}
            </span>
          </div>
          <div className="text-2xl font-bold text-foreground">{stat.value}</div>
          <div className="text-sm text-muted-foreground">{stat.label}</div>
        </div>
      ))}
    </div>
  )
}
