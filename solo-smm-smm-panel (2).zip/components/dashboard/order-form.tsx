"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ShoppingCart, LinkIcon, Hash, Calculator, Zap } from "lucide-react"

const categories = [
  { value: "instagram", label: "Instagram" },
  { value: "youtube", label: "YouTube" },
  { value: "tiktok", label: "TikTok" },
  { value: "twitter", label: "Twitter" },
  { value: "telegram", label: "Telegram" },
]

const services = {
  instagram: [
    { id: "1", name: "Instagram Türk Takipçi", price: 0.015, min: 100, max: 100000 },
    { id: "2", name: "Instagram Global Takipçi", price: 0.008, min: 100, max: 500000 },
    { id: "3", name: "Instagram Türk Beğeni", price: 0.01, min: 50, max: 50000 },
    { id: "4", name: "Instagram İzlenme", price: 0.002, min: 500, max: 1000000 },
  ],
  youtube: [
    { id: "5", name: "YouTube Abone", price: 0.2, min: 50, max: 10000 },
    { id: "6", name: "YouTube İzlenme", price: 0.005, min: 1000, max: 1000000 },
    { id: "7", name: "YouTube Beğeni", price: 0.015, min: 100, max: 50000 },
  ],
  tiktok: [
    { id: "8", name: "TikTok Takipçi", price: 0.012, min: 100, max: 100000 },
    { id: "9", name: "TikTok Beğeni", price: 0.005, min: 100, max: 500000 },
    { id: "10", name: "TikTok İzlenme", price: 0.001, min: 1000, max: 10000000 },
  ],
  twitter: [
    { id: "11", name: "Twitter Takipçi", price: 0.025, min: 100, max: 50000 },
    { id: "12", name: "Twitter Beğeni", price: 0.01, min: 100, max: 100000 },
  ],
  telegram: [
    { id: "13", name: "Telegram Üye", price: 0.008, min: 100, max: 100000 },
    { id: "14", name: "Telegram Görüntüleme", price: 0.001, min: 500, max: 500000 },
  ],
}

export function OrderForm() {
  const [category, setCategory] = useState<string>("")
  const [service, setService] = useState<string>("")
  const [link, setLink] = useState("")
  const [quantity, setQuantity] = useState("")

  const availableServices = category ? services[category as keyof typeof services] : []
  const selectedService = availableServices.find((s) => s.id === service)
  const totalPrice = selectedService && quantity ? selectedService.price * Number.parseInt(quantity) : 0

  return (
    <div className="glass rounded-xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <ShoppingCart className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Yeni Sipariş</h2>
          <p className="text-sm text-muted-foreground">Servis seçin ve sipariş verin</p>
        </div>
      </div>

      <div className="space-y-5">
        {/* Category Selection */}
        <div className="space-y-2">
          <Label className="text-foreground">Kategori</Label>
          <Select
            value={category}
            onValueChange={(val) => {
              setCategory(val)
              setService("")
            }}
          >
            <SelectTrigger className="bg-secondary/50 border-border">
              <SelectValue placeholder="Kategori seçin" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat.value} value={cat.value}>
                  {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Service Selection */}
        <div className="space-y-2">
          <Label className="text-foreground">Servis</Label>
          <Select value={service} onValueChange={setService} disabled={!category}>
            <SelectTrigger className="bg-secondary/50 border-border">
              <SelectValue placeholder="Servis seçin" />
            </SelectTrigger>
            <SelectContent>
              {availableServices.map((srv) => (
                <SelectItem key={srv.id} value={srv.id}>
                  {srv.name} - ₺{srv.price.toFixed(3)}/adet
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Link Input */}
        <div className="space-y-2">
          <Label className="text-foreground">Link</Label>
          <div className="relative">
            <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Profil veya içerik linki"
              value={link}
              onChange={(e) => setLink(e.target.value)}
              className="pl-10 bg-secondary/50 border-border"
            />
          </div>
        </div>

        {/* Quantity Input */}
        <div className="space-y-2">
          <Label className="text-foreground">Miktar</Label>
          <div className="relative">
            <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              placeholder={
                selectedService ? `Min: ${selectedService.min} - Max: ${selectedService.max}` : "Miktar girin"
              }
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              className="pl-10 bg-secondary/50 border-border"
              min={selectedService?.min}
              max={selectedService?.max}
            />
          </div>
        </div>

        {/* Price Calculator */}
        {selectedService && quantity && (
          <div className="glass rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calculator className="w-5 h-5 text-primary" />
              <span className="text-muted-foreground">Toplam Tutar:</span>
            </div>
            <span className="text-xl font-bold text-foreground">₺{totalPrice.toFixed(2)}</span>
          </div>
        )}

        {/* Submit Button */}
        <Button
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-6 text-lg"
          disabled={!category || !service || !link || !quantity}
        >
          <Zap className="w-5 h-5 mr-2" />
          Sipariş Ver
        </Button>
      </div>
    </div>
  )
}
