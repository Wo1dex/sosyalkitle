"use client"

import { Clock, CheckCircle, Loader2, XCircle } from "lucide-react"

const orders = [
  { id: "#12345", service: "Instagram Türk Takipçi", quantity: 1000, status: "completed", date: "2 saat önce" },
  { id: "#12344", service: "YouTube İzlenme", quantity: 5000, status: "processing", date: "4 saat önce" },
  { id: "#12343", service: "TikTok Beğeni", quantity: 2500, status: "pending", date: "6 saat önce" },
  { id: "#12342", service: "Twitter Takipçi", quantity: 500, status: "completed", date: "1 gün önce" },
  { id: "#12341", service: "Instagram Beğeni", quantity: 3000, status: "cancelled", date: "1 gün önce" },
]

const statusConfig = {
  completed: { icon: CheckCircle, label: "Tamamlandı", color: "text-green-400 bg-green-400/10" },
  processing: { icon: Loader2, label: "İşleniyor", color: "text-primary bg-primary/10", animate: true },
  pending: { icon: Clock, label: "Bekliyor", color: "text-yellow-400 bg-yellow-400/10" },
  cancelled: { icon: XCircle, label: "İptal", color: "text-red-400 bg-red-400/10" },
}

export function RecentOrders() {
  return (
    <div className="glass rounded-xl p-6">
      <h2 className="text-lg font-semibold text-foreground mb-4">Son Siparişler</h2>

      <div className="space-y-3">
        {orders.map((order) => {
          const status = statusConfig[order.status as keyof typeof statusConfig]
          return (
            <div
              key={order.id}
              className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono text-sm text-muted-foreground">{order.id}</span>
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${status.color}`}>
                    <status.icon className={`w-3 h-3 ${status.animate ? "animate-spin" : ""}`} />
                    {status.label}
                  </span>
                </div>
                <div className="text-sm text-foreground">{order.service}</div>
                <div className="text-xs text-muted-foreground">{order.date}</div>
              </div>
              <div className="text-right">
                <div className="font-semibold text-foreground">{order.quantity.toLocaleString()}</div>
                <div className="text-xs text-muted-foreground">adet</div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
