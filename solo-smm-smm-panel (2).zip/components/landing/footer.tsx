"use client"

import Link from "next/link"
import { Users, Instagram, Twitter, Send, MessageCircle } from "lucide-react"

export function Footer() {
  return (
    <footer className="py-12 border-t border-primary/10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-emerald-400 flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-foreground">Sosyalkitle</span>
          </Link>

          {/* Links */}
          <nav className="flex flex-wrap items-center justify-center gap-6 text-sm">
            <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
              Kullanım Şartları
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
              Gizlilik Politikası
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
              KVKK
            </Link>
          </nav>

          {/* Social - Updated social media links */}
          <div className="flex gap-3">
            <a
              href="https://instagram.com/sosyalkitle1"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-xl glass-card flex items-center justify-center hover:border-primary/40 transition-colors group"
            >
              <Instagram className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
            </a>
            <a
              href="https://twitter.com/sosyalkitle"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-xl glass-card flex items-center justify-center hover:border-primary/40 transition-colors group"
            >
              <Twitter className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
            </a>
            <a
              href="https://t.me/Sosyalkitle1"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-xl glass-card flex items-center justify-center hover:border-primary/40 transition-colors group"
            >
              <Send className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
            </a>
            <a
              href="https://wa.me/15814304606"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-xl glass-card flex items-center justify-center hover:border-primary/40 transition-colors group"
            >
              <MessageCircle className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
            </a>
          </div>
        </div>

        <div className="border-t border-primary/10 mt-8 pt-8 text-center text-sm text-muted-foreground">
          © 2017 - 2026 Sosyalkitle. Tüm hakları saklıdır.
        </div>
      </div>
    </footer>
  )
}
