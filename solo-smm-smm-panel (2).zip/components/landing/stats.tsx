"use client"

import { useEffect, useState, useRef } from "react"
import { ShoppingCart, Users, Award, Clock } from "lucide-react"

const stats = [
  {
    icon: ShoppingCart,
    value: 1250000,
    suffix: "+",
    label: "Tamamlanan Sipariş",
  },
  {
    icon: Users,
    value: 45000,
    suffix: "+",
    label: "Mutlu Müşteri",
  },
  {
    icon: Award,
    value: 99.9,
    suffix: "%",
    label: "Memnuniyet Oranı",
  },
  {
    icon: Clock,
    value: 24,
    suffix: "/7",
    label: "Kesintisiz Hizmet",
  },
]

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!isVisible) return

    const duration = 2000
    const steps = 60
    const increment = value / steps
    let current = 0

    const timer = setInterval(() => {
      current += increment
      if (current >= value) {
        setCount(value)
        clearInterval(timer)
      } else {
        setCount(Math.floor(current))
      }
    }, duration / steps)

    return () => clearInterval(timer)
  }, [isVisible, value])

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + "M"
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(0) + "K"
    }
    return num.toString()
  }

  return (
    <div ref={ref} className="text-4xl md:text-5xl font-bold text-foreground">
      {formatNumber(count)}
      {suffix}
    </div>
  )
}

export function Stats() {
  return (
    <section id="stats" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-primary/5" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">Canlı İstatistikler</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">Rakamlarla Sosyalkitle</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="glass-card rounded-2xl p-6 md:p-8 text-center hover:border-primary/40 transition-all group"
            >
              <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-6 group-hover:from-primary/30 transition-all">
                <stat.icon className="w-8 h-8 text-primary" />
              </div>
              <AnimatedCounter value={stat.value} suffix={stat.suffix} />
              <div className="text-muted-foreground mt-2">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
