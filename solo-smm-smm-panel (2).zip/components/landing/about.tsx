"use client"

import { CheckCircle, Instagram, Send, Twitter } from "lucide-react"

const highlights = [
  "2017'den beri sektörde",
  "45.000+ mutlu müşteri",
  "API destekli altyapı",
  "7/24 teknik destek",
  "7 kişilik uzman ekip",
  "Anında sipariş işleme",
]

export function About() {
  return (
    <section id="about" className="py-24 relative">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left - Text Content */}
          <div>
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">Hakkımızda</h2>
            <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
              Sosyalkitle, 2017 yılından bu yana Türkiye'nin en güvenilir SMM panel hizmeti olarak binlerce müşteriye
              kesintisiz hizmet vermektedir. İstanbul Maslak'taki ofisimizde 7 kişilik uzman ekibimizle sosyal medya
              hesaplarınızı büyütmenize yardımcı oluyoruz.
            </p>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              Müşteri memnuniyetini ön planda tutarak, en uygun fiyatlarla en kaliteli hizmeti sunmayı hedefliyoruz. Tüm
              sosyal medya platformları için 1000'den fazla aktif servisimiz ile ihtiyacınız olan her şey burada.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {highlights.map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-foreground">{item}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <span className="text-muted-foreground text-sm">Bizi Takip Edin:</span>
              <a
                href="https://instagram.com/sosyalkitle1"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl glass-card flex items-center justify-center hover:border-primary/40 transition-colors group"
              >
                <Instagram className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
              </a>
              <a
                href="https://t.me/Sosyalkitle1"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl glass-card flex items-center justify-center hover:border-primary/40 transition-colors group"
              >
                <Send className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
              </a>
              <a
                href="https://twitter.com/sosyalkitle"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl glass-card flex items-center justify-center hover:border-primary/40 transition-colors group"
              >
                <Twitter className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
              </a>
            </div>
          </div>

          {/* Right - Visual Card */}
          <div className="glass-card rounded-3xl p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-[100px]" />

            <div className="relative z-10 space-y-6">
              <div className="flex items-center gap-4 p-4 rounded-xl bg-background/50">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-emerald-400 flex items-center justify-center text-white font-bold text-xl">
                  S
                </div>
                <div>
                  <div className="font-semibold text-foreground">Sosyalkitle</div>
                  <div className="text-sm text-muted-foreground">Premium SMM Panel</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-background/50 text-center">
                  <div className="text-2xl font-bold text-primary">1000+</div>
                  <div className="text-sm text-muted-foreground">Aktif Servis</div>
                </div>
                <div className="p-4 rounded-xl bg-background/50 text-center">
                  <div className="text-2xl font-bold text-primary">9+</div>
                  <div className="text-sm text-muted-foreground">Yıllık Deneyim</div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-primary/20 to-primary/5">
                <div className="text-sm text-muted-foreground mb-1">Güven Puanı</div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 rounded-full bg-background/50 overflow-hidden">
                    <div className="h-full w-[99%] bg-gradient-to-r from-primary to-emerald-400 rounded-full" />
                  </div>
                  <span className="text-foreground font-semibold">99%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
