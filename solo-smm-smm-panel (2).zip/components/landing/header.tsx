"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Users, Menu, X } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-primary/10">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-emerald-400 flex items-center justify-center shadow-lg shadow-primary/25">
            <Users className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold text-foreground">Sosyalkitle</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="#features" className="text-muted-foreground hover:text-primary transition-colors">
            Özellikler
          </Link>
          <Link href="#stats" className="text-muted-foreground hover:text-primary transition-colors">
            İstatistikler
          </Link>
          <Link href="#about" className="text-muted-foreground hover:text-primary transition-colors">
            Hakkımızda
          </Link>
          <Link href="#contact" className="text-muted-foreground hover:text-primary transition-colors">
            İletişim
          </Link>
        </nav>

        {/* Auth Buttons - Glassmorphism */}
        <div className="hidden md:flex items-center gap-3">
          <Link href="/dashboard">
            <Button variant="ghost" className="glass-card hover:bg-primary/10 text-foreground border-primary/20">
              Giriş Yap
            </Button>
          </Link>
          <Link href="/dashboard">
            <Button className="bg-gradient-to-r from-primary to-emerald-400 hover:opacity-90 text-white shadow-lg shadow-primary/25">
              Kayıt Ol
            </Button>
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden p-2 text-muted-foreground hover:text-foreground transition-colors"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Menüyü aç/kapat"
        >
          {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-background/95 backdrop-blur-xl border-t border-primary/10">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-4">
            <Link
              href="#features"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Özellikler
            </Link>
            <Link
              href="#stats"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              İstatistikler
            </Link>
            <Link
              href="#about"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Hakkımızda
            </Link>
            <Link
              href="#contact"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              İletişim
            </Link>
            <div className="flex flex-col gap-2 pt-4 border-t border-primary/10">
              <Link href="/dashboard" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full glass-card hover:bg-primary/10">
                  Giriş Yap
                </Button>
              </Link>
              <Link href="/dashboard" onClick={() => setIsMenuOpen(false)}>
                <Button className="w-full bg-gradient-to-r from-primary to-emerald-400 text-white">Kayıt Ol</Button>
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
