"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Zap, Shield, Rocket } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background - Night black with emerald accents */}
      <div className="absolute inset-0 bg-background">
        {/* Emerald Glow Effects */}
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-primary/15 rounded-full blur-[150px] animate-glow" />
        <div
          className="absolute bottom-1/3 right-1/4 w-[400px] h-[400px] bg-primary/10 rounded-full blur-[120px] animate-glow"
          style={{ animationDelay: "2s" }}
        />
      </div>

      {/* Tech Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(16,185,129,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(16,185,129,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />

      {/* Animated Tech Lines */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent animate-line" />
        <div
          className="absolute top-2/4 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent animate-line"
          style={{ animationDelay: "1s" }}
        />
        <div
          className="absolute top-3/4 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/25 to-transparent animate-line"
          style={{ animationDelay: "2s" }}
        />
      </div>

      {/* Floating 3D Elements */}
      <div
        className="absolute top-32 left-16 w-14 h-14 glass-card rounded-xl animate-float flex items-center justify-center"
        style={{ animationDelay: "0s" }}
      >
        <Zap className="w-7 h-7 text-primary" />
      </div>
      <div
        className="absolute top-48 right-24 w-16 h-16 glass-card rounded-xl animate-float flex items-center justify-center"
        style={{ animationDelay: "1.5s" }}
      >
        <Shield className="w-8 h-8 text-primary" />
      </div>
      <div
        className="absolute bottom-48 left-24 w-12 h-12 glass-card rounded-xl animate-float flex items-center justify-center"
        style={{ animationDelay: "0.8s" }}
      >
        <Rocket className="w-6 h-6 text-primary" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-8">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-sm text-muted-foreground">{"Türkiye'nin Güvenilir SMM Paneli"}</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight text-balance">
            <span className="text-foreground">Sosyal Medyada </span>
            <span className="bg-gradient-to-r from-primary to-emerald-300 bg-clip-text text-transparent">
              Kitleni Büyüt
            </span>
          </h1>

          {/* Subtext */}
          <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto text-pretty">
            API destekli, hızlı ve güvenilir servisler ile sosyal medya hesaplarınızı profesyonelce yönetin.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/dashboard">
              <Button
                size="lg"
                className="bg-gradient-to-r from-primary to-emerald-400 hover:opacity-90 text-white px-8 py-6 text-lg group shadow-xl shadow-primary/25"
              >
                Hemen Başla
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="#features">
              <Button
                size="lg"
                variant="outline"
                className="px-8 py-6 text-lg glass-card border-primary/30 hover:bg-primary/10 text-foreground bg-transparent"
              >
                Daha Fazla Bilgi
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
