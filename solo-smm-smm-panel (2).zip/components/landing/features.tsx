"use client"

import { Zap, Shield, Clock, Layers, TrendingUp, DollarSign } from "lucide-react"

const features = [
  {
    icon: Layers,
    title: "1000+ Aktif Servis",
    description: "Tüm sosyal medya platformları için binlerce farklı servis seçeneği.",
  },
  {
    icon: Zap,
    title: "Anlık Teslimat",
    description: "Siparişleriniz saniyeler içinde işleme alınır ve anında teslim edilir.",
  },
  {
    icon: DollarSign,
    title: "En Uygun Fiyatlar",
    description: "Piyasanın en rekabetçi fiyatları ile kaliteli hizmet garantisi.",
  },
  {
    icon: Shield,
    title: "Güvenli Altyapı",
    description: "SSL şifrelemeli güvenli ödeme ve veri koruma sistemleri.",
  },
  {
    icon: Clock,
    title: "7/24 Çalışan Sistem",
    description: "Kesintisiz hizmet, istediğiniz zaman sipariş verebilirsiniz.",
  },
  {
    icon: TrendingUp,
    title: "API Desteği",
    description: "Gelişmiş API altyapısı ile kendi sisteminize entegre edin.",
  },
]

export function Features() {
  return (
    <section id="features" className="py-24 relative">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">Neden Biz?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            API destekli servislerimizin neden en iyi tercih olduğunu keşfedin.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="glass-card rounded-2xl p-6 hover:border-primary/40 transition-all duration-300 group hover:shadow-xl hover:shadow-primary/10"
            >
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-5 group-hover:from-primary/30 group-hover:to-primary/10 transition-all">
                <feature.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
