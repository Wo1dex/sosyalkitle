"use client"

import { Button } from "@/components/ui/button"
import { Mail, MapPin, MessageCircle } from "lucide-react"

export function Contact() {
  return (
    <section id="contact" className="py-24 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">İletişim</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">Sorularınız için bize ulaşın</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* WhatsApp Support - Updated phone number */}
            <div className="glass-card rounded-2xl p-6 text-center hover:border-primary/40 transition-all group">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-green-500/20 flex items-center justify-center mb-4 group-hover:bg-green-500/30 transition-all">
                <MessageCircle className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">WhatsApp Destek</h3>
              <p className="text-muted-foreground text-sm mb-4">7/24 anlık destek hattı</p>
              <a href="https://wa.me/15814304606" target="_blank" rel="noopener noreferrer">
                <Button className="w-full bg-green-500 hover:bg-green-600 text-white">WhatsApp ile Yazın</Button>
              </a>
            </div>

            {/* Email - Updated email address */}
            <div className="glass-card rounded-2xl p-6 text-center hover:border-primary/40 transition-all group">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/20 flex items-center justify-center mb-4 group-hover:bg-primary/30 transition-all">
                <Mail className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">E-posta</h3>
              <p className="text-muted-foreground text-sm mb-4">destek@sosyalkitle.com</p>
              <a href="mailto:destek@sosyalkitle.com">
                <Button
                  variant="outline"
                  className="w-full glass-card border-primary/30 hover:bg-primary/10 bg-transparent"
                >
                  E-posta Gönder
                </Button>
              </a>
            </div>

            {/* Location - Updated full address */}
            <div className="glass-card rounded-2xl p-6 text-center hover:border-primary/40 transition-all group">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/20 flex items-center justify-center mb-4 group-hover:bg-primary/30 transition-all">
                <MapPin className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Adres</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Maslak Mah. Büyükdere Cad. No:255 Nurol Plaza Kat:8 Sarıyer/İstanbul
              </p>
              <a
                href="https://maps.google.com/?q=Maslak+Büyükdere+Caddesi+255+Nurol+Plaza+İstanbul"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  variant="outline"
                  className="w-full glass-card border-primary/30 hover:bg-primary/10 bg-transparent"
                >
                  Haritada Gör
                </Button>
              </a>
            </div>
          </div>

          {/* Extra Info */}
          <div className="mt-12 glass-card rounded-2xl p-6 text-center">
            <p className="text-muted-foreground">
              <span className="text-primary font-semibold">Ortalama yanıt süresi:</span> 5 dakika içinde
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
