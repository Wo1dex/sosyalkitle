"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CreditCard, Building, Bitcoin, Wallet, Plus, History } from "lucide-react"

const paymentMethods = [
  { id: "card", icon: CreditCard, label: "Kredi Kartı", description: "Visa, Mastercard" },
  { id: "bank", icon: Building, label: "Banka Havalesi", description: "EFT/Havale" },
  { id: "crypto", icon: Bitcoin, label: "Kripto Para", description: "BTC, ETH, USDT" },
]

const transactions = [
  { id: 1, type: "deposit", amount: 500, method: "Kredi Kartı", date: "13 Ocak 2026", status: "completed" },
  { id: 2, type: "order", amount: -15, service: "Instagram Takipçi", date: "13 Ocak 2026", status: "completed" },
  { id: 3, type: "deposit", amount: 200, method: "Banka Havalesi", date: "12 Ocak 2026", status: "completed" },
  { id: 4, type: "order", amount: -25, service: "YouTube İzlenme", date: "12 Ocak 2026", status: "completed" },
  { id: 5, type: "order", amount: -8, service: "Telegram Üye", date: "11 Ocak 2026", status: "completed" },
]

export default function BalancePage() {
  const [amount, setAmount] = useState("")
  const [selectedMethod, setSelectedMethod] = useState("card")

  const quickAmounts = [50, 100, 250, 500, 1000]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Bakiye Ekle</h1>
        <p className="text-muted-foreground">Hesabınıza bakiye yükleyin.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Add Balance Form */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Wallet className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Bakiye Yükle</h2>
              <p className="text-sm text-muted-foreground">Mevcut bakiye: ₺2,547.50</p>
            </div>
          </div>

          <div className="space-y-5">
            {/* Amount Input */}
            <div className="space-y-2">
              <Label className="text-foreground">Tutar (₺)</Label>
              <Input
                type="number"
                placeholder="Yüklenecek tutar"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-secondary/50 border-border text-lg py-6"
              />
              <div className="flex gap-2 mt-2">
                {quickAmounts.map((q) => (
                  <Button
                    key={q}
                    variant="outline"
                    size="sm"
                    onClick={() => setAmount(q.toString())}
                    className="flex-1 border-border hover:bg-primary/10 hover:border-primary/50"
                  >
                    ₺{q}
                  </Button>
                ))}
              </div>
            </div>

            {/* Payment Method */}
            <div className="space-y-2">
              <Label className="text-foreground">Ödeme Yöntemi</Label>
              <div className="grid grid-cols-1 gap-3">
                {paymentMethods.map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setSelectedMethod(method.id)}
                    className={`flex items-center gap-4 p-4 rounded-lg border transition-all ${
                      selectedMethod === method.id
                        ? "border-primary bg-primary/10"
                        : "border-border bg-secondary/30 hover:bg-secondary/50"
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        selectedMethod === method.id ? "bg-primary/20" : "bg-secondary"
                      }`}
                    >
                      <method.icon
                        className={`w-5 h-5 ${selectedMethod === method.id ? "text-primary" : "text-muted-foreground"}`}
                      />
                    </div>
                    <div className="text-left">
                      <div className="font-medium text-foreground">{method.label}</div>
                      <div className="text-sm text-muted-foreground">{method.description}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <Button
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-6 text-lg"
              disabled={!amount}
            >
              <Plus className="w-5 h-5 mr-2" />₺{amount || "0"} Yükle
            </Button>
          </div>
        </div>

        {/* Transaction History */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <History className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">İşlem Geçmişi</h2>
              <p className="text-sm text-muted-foreground">Son işlemleriniz</p>
            </div>
          </div>

          <div className="space-y-3">
            {transactions.map((tx) => (
              <div key={tx.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      tx.type === "deposit" ? "bg-green-400/10" : "bg-red-400/10"
                    }`}
                  >
                    {tx.type === "deposit" ? (
                      <Plus className="w-5 h-5 text-green-400" />
                    ) : (
                      <Wallet className="w-5 h-5 text-red-400" />
                    )}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-foreground">
                      {tx.type === "deposit" ? tx.method : tx.service}
                    </div>
                    <div className="text-xs text-muted-foreground">{tx.date}</div>
                  </div>
                </div>
                <div className={`font-semibold ${tx.amount > 0 ? "text-green-400" : "text-red-400"}`}>
                  {tx.amount > 0 ? "+" : ""}₺{Math.abs(tx.amount).toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
