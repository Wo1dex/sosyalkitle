"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Clock, CheckCircle, Loader2, XCircle, Eye } from "lucide-react"

const allOrders = [
  {
    id: "#12345",
    service: "Instagram Türk Takipçi",
    link: "instagram.com/example",
    quantity: 1000,
    start: 850,
    remains: 150,
    status: "completed",
    date: "13 Ocak 2026",
    price: 15.0,
  },
  {
    id: "#12344",
    service: "YouTube İzlenme",
    link: "youtube.com/watch?v=xxx",
    quantity: 5000,
    start: 2500,
    remains: 2500,
    status: "processing",
    date: "13 Ocak 2026",
    price: 25.0,
  },
  {
    id: "#12343",
    service: "TikTok Beğeni",
    link: "tiktok.com/@user/video/xxx",
    quantity: 2500,
    start: 0,
    remains: 2500,
    status: "pending",
    date: "12 Ocak 2026",
    price: 12.5,
  },
  {
    id: "#12342",
    service: "Twitter Takipçi",
    link: "twitter.com/example",
    quantity: 500,
    start: 500,
    remains: 0,
    status: "completed",
    date: "12 Ocak 2026",
    price: 12.5,
  },
  {
    id: "#12341",
    service: "Instagram Beğeni",
    link: "instagram.com/p/xxx",
    quantity: 3000,
    start: 0,
    remains: 3000,
    status: "cancelled",
    date: "11 Ocak 2026",
    price: 30.0,
  },
  {
    id: "#12340",
    service: "Telegram Üye",
    link: "t.me/example",
    quantity: 1000,
    start: 1000,
    remains: 0,
    status: "completed",
    date: "10 Ocak 2026",
    price: 8.0,
  },
]

const statusConfig = {
  completed: { icon: CheckCircle, label: "Tamamlandı", color: "text-green-400 bg-green-400/10" },
  processing: { icon: Loader2, label: "İşleniyor", color: "text-primary bg-primary/10", animate: true },
  pending: { icon: Clock, label: "Bekliyor", color: "text-yellow-400 bg-yellow-400/10" },
  cancelled: { icon: XCircle, label: "İptal", color: "text-red-400 bg-red-400/10" },
}

export default function OrdersPage() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredOrders = allOrders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(search.toLowerCase()) ||
      order.service.toLowerCase().includes(search.toLowerCase())
    const matchesStatus = statusFilter === "all" || order.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Siparişlerim</h1>
        <p className="text-muted-foreground">Tüm siparişlerinizi görüntüleyin ve takip edin.</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Sipariş ID veya servis ara..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-secondary/50 border-border"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48 bg-secondary/50 border-border">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Durum filtrele" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tümü</SelectItem>
            <SelectItem value="completed">Tamamlandı</SelectItem>
            <SelectItem value="processing">İşleniyor</SelectItem>
            <SelectItem value="pending">Bekliyor</SelectItem>
            <SelectItem value="cancelled">İptal</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Orders Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary/50">
              <tr className="text-left text-sm text-muted-foreground">
                <th className="px-4 py-3 font-medium">ID</th>
                <th className="px-4 py-3 font-medium">Servis</th>
                <th className="px-4 py-3 font-medium">Miktar</th>
                <th className="px-4 py-3 font-medium">Başlangıç</th>
                <th className="px-4 py-3 font-medium">Kalan</th>
                <th className="px-4 py-3 font-medium">Durum</th>
                <th className="px-4 py-3 font-medium">Tarih</th>
                <th className="px-4 py-3 font-medium">Tutar</th>
                <th className="px-4 py-3 font-medium"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredOrders.map((order) => {
                const status = statusConfig[order.status as keyof typeof statusConfig]
                return (
                  <tr key={order.id} className="hover:bg-secondary/30 transition-colors">
                    <td className="px-4 py-4 font-mono text-sm text-foreground">{order.id}</td>
                    <td className="px-4 py-4 text-sm text-foreground">{order.service}</td>
                    <td className="px-4 py-4 text-sm text-foreground">{order.quantity.toLocaleString()}</td>
                    <td className="px-4 py-4 text-sm text-muted-foreground">{order.start.toLocaleString()}</td>
                    <td className="px-4 py-4 text-sm text-muted-foreground">{order.remains.toLocaleString()}</td>
                    <td className="px-4 py-4">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs ${status.color}`}>
                        <status.icon className={`w-3 h-3 ${status.animate ? "animate-spin" : ""}`} />
                        {status.label}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm text-muted-foreground">{order.date}</td>
                    <td className="px-4 py-4 text-sm font-medium text-foreground">₺{order.price.toFixed(2)}</td>
                    <td className="px-4 py-4">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      </Button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
