import { OrderForm } from "@/components/dashboard/order-form"

export default function NewOrderPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Yeni Sipariş</h1>
        <p className="text-muted-foreground">Servis seçin ve hemen sipariş verin.</p>
      </div>

      <div className="max-w-2xl">
        <OrderForm />
      </div>
    </div>
  )
}
