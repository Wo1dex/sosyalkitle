"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Code, Copy, Eye, EyeOff, RefreshCw, Book, ExternalLink } from "lucide-react"

export default function ApiPage() {
  const [showKey, setShowKey] = useState(false)
  const apiKey = "sk_live_SoloSMM_xxxxxxxxxxxxxxxxxxxx"
  const apiUrl = "https://api.solosmm.com/v1"

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const codeExample = `// Sipariş Oluşturma Örneği
const response = await fetch('${apiUrl}/orders', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    service: 1,
    link: 'https://instagram.com/example',
    quantity: 1000
  })
});

const data = await response.json();
console.log(data);`

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">API Erişimi</h1>
        <p className="text-muted-foreground">API anahtarınızı yönetin ve dökümantasyona erişin.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* API Credentials */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Code className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">API Bilgileri</h2>
              <p className="text-sm text-muted-foreground">Entegrasyon için gerekli bilgiler</p>
            </div>
          </div>

          <div className="space-y-5">
            {/* API URL */}
            <div className="space-y-2">
              <Label className="text-foreground">API URL</Label>
              <div className="flex gap-2">
                <Input value={apiUrl} readOnly className="bg-secondary/50 border-border font-mono text-sm" />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(apiUrl)}
                  className="border-border hover:bg-primary/10"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* API Key */}
            <div className="space-y-2">
              <Label className="text-foreground">API Anahtarı</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    type={showKey ? "text" : "password"}
                    value={apiKey}
                    readOnly
                    className="bg-secondary/50 border-border font-mono text-sm pr-10"
                  />
                  <button
                    onClick={() => setShowKey(!showKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(apiKey)}
                  className="border-border hover:bg-primary/10"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1 border-border hover:bg-primary/10 bg-transparent">
                <RefreshCw className="w-4 h-4 mr-2" />
                Yeni Anahtar Oluştur
              </Button>
            </div>

            {/* Documentation Link */}
            <div className="glass rounded-lg p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Book className="w-5 h-5 text-primary" />
                <div>
                  <div className="font-medium text-foreground">API Dökümantasyonu</div>
                  <div className="text-sm text-muted-foreground">Detaylı kullanım rehberi</div>
                </div>
              </div>
              <Button variant="ghost" size="icon">
                <ExternalLink className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Code Example */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Örnek Kod</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => copyToClipboard(codeExample)}
              className="text-muted-foreground hover:text-foreground"
            >
              <Copy className="w-4 h-4 mr-2" />
              Kopyala
            </Button>
          </div>
          <pre className="bg-background/50 rounded-lg p-4 overflow-x-auto">
            <code className="text-sm text-muted-foreground font-mono whitespace-pre">{codeExample}</code>
          </pre>

          {/* Endpoints */}
          <div className="mt-6 space-y-3">
            <h4 className="font-medium text-foreground">Endpointler</h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 p-2 rounded bg-secondary/30">
                <span className="px-2 py-0.5 rounded bg-green-400/10 text-green-400 text-xs font-mono">GET</span>
                <span className="text-muted-foreground font-mono">/services</span>
                <span className="text-muted-foreground ml-auto">Servis listesi</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded bg-secondary/30">
                <span className="px-2 py-0.5 rounded bg-primary/20 text-primary text-xs font-mono">POST</span>
                <span className="text-muted-foreground font-mono">/orders</span>
                <span className="text-muted-foreground ml-auto">Sipariş oluştur</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded bg-secondary/30">
                <span className="px-2 py-0.5 rounded bg-green-400/10 text-green-400 text-xs font-mono">GET</span>
                <span className="text-muted-foreground font-mono">{"/orders/{id}"}</span>
                <span className="text-muted-foreground ml-auto">Sipariş durumu</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded bg-secondary/30">
                <span className="px-2 py-0.5 rounded bg-green-400/10 text-green-400 text-xs font-mono">GET</span>
                <span className="text-muted-foreground font-mono">/balance</span>
                <span className="text-muted-foreground ml-auto">Bakiye sorgula</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
