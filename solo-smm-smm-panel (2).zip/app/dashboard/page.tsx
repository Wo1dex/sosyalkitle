import { StatsCards } from "@/components/dashboard/stats-cards"
import { OrderForm } from "@/components/dashboard/order-form"
import { RecentOrders } from "@/components/dashboard/recent-orders"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Hoş geldiniz! İşte hesap özetiniz.</p>
      </div>

      <StatsCards />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <OrderForm />
        <RecentOrders />
      </div>
    </div>
  )
}
